﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RajSoniPricingAsh
{
    public class Item
    {
        public string Product { get; set; }
        public decimal price { get; set; }
        public decimal discount { get; set; }
        
        

    }
}